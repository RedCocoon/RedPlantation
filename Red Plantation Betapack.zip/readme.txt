Make sure you are in the latest version of minecraft.
Installation:
Put the "Red Plantaion Texture Pack" Folder in .../.minecraft/resourcepacks
Put the "Red Plantation Datapack" Folder in ../.minecraft/saves/<your world>/datapacks
If you are already in world, do /reload.
If else, it should start automagically after you loaded the world.
=====
Contact me on discord if you have any questions/problems.
=====
<<//==[[DO NOT DISTRIBUTE WITHOUT PERMISSION]]==\\>>